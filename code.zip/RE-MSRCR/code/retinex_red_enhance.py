import numpy as np
from .tools import measure_time, eps, gauss_blur, simplest_color_balance


def compute_channel_weights(img):
    mean_values = np.mean(img, axis=(0, 1)) + eps
    red_ratio = np.max(mean_values) / mean_values[2]
    enhance_factor = np.clip(red_ratio * 0.8, 2.0, 4.0)
    weights = 1 / mean_values
    weights[2] *= enhance_factor
    max_weight = 3.5 * np.min(weights)
    weights = np.clip(weights, None, max_weight)
    weights /= np.sum(weights)
    return weights

def MultiScaleRetinex(img, sigmas=[15, 80, 250], weights=None, flag=True):
    if weights is None:
        weights = compute_channel_weights(img)
    elif not abs(sum(weights) - 1) < 0.00001:
        raise ValueError('The sum of the weights must be 1!')

    img = img.astype('double')
    r = np.zeros_like(img, dtype='double')

    gaussian_blurs = [gauss_blur(img, sigma) for sigma in sigmas]
    log_img = np.log(img + 1)

    for i, sigma in enumerate(sigmas):
        r += (log_img - np.log(gaussian_blurs[i] + 1)) * weights[i]

    if flag:
        r_min, r_max = np.min(r, axis=(0, 1), keepdims=True), np.max(r, axis=(0, 1), keepdims=True)
        r = (r - r_min) / (r_max - r_min) * 255
        r = r.astype('uint8')

    return r

@measure_time
def retinex_MSRCR(img, sigmas=[12, 80, 250], s1=0.01, s2=0.02):
    alpha = 125
    img = img.astype('double') + 1
    csum_log = np.log(np.sum(img, axis=2))

    msr = MultiScaleRetinex(img - 1, sigmas)

    r = (np.log(alpha * img) - csum_log[..., None]) * msr

    if not (0 <= s1 < s2 <= 1):
        raise ValueError(f"s1 ({s1}) and s2 ({s2}) must be within [0, 1] and s1 < s2")

    for i in range(r.shape[-1]):
        r[..., i] = simplest_color_balance(r[..., i], s1, s2)

    return r.astype('uint8')