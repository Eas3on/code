#ifndef MAIN_H
#define MAIN_H

void fast_gauss_blur(double *image,double *result,int w,int h,int channel_num,double sigma,int box_num);

#endif