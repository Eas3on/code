import time
import numpy as np
from functools import wraps
import cv2
import os.path

eps = np.finfo(np.double).eps

def measure_time(wrapped):
    @wraps(wrapped)
    def wrapper(*args, **kwds):
        t1 = time.time()
        ret = wrapped(*args, **kwds)
        t2 = time.time()
        print('@measure_time: {0} took {1} seconds'.format(wrapped.__name__, t2 - t1))
        return ret
    return wrapper

def get_gauss_kernel(sigma, dim=2):
    ksize = int(np.floor(sigma * 6) / 2) * 2 + 1
    k_1D = np.arange(ksize) - ksize // 2
    k_1D = np.exp(-k_1D**2 / (2 * sigma**2))
    k_1D = k_1D / np.sum(k_1D)
    if dim == 1:
        return k_1D
    elif dim == 2:
        return k_1D[:, None].dot(k_1D.reshape(1, -1))

def gauss_blur_original(img, sigma):
    row_filter = get_gauss_kernel(sigma, 1)
    t = cv2.filter2D(img, -1, row_filter[..., None])
    return cv2.filter2D(t, -1, row_filter.reshape(1, -1))

def _get_optimized_kernel(sigma):
    ksize = int(2 * 3 * sigma + 1) | 1
    kernel = cv2.getGaussianKernel(ksize, sigma, cv2.CV_64F)
    kernel = kernel * kernel.T
    return kernel

def gauss_blur_recursive(img, sigma):
    pass

def gauss_blur(img, sigma, method='original'):
    if method == 'original':
        return gauss_blur_original(img, sigma)
    elif method == 'recursive':
        return gauss_blur_recursive(img, sigma)

def simplest_color_balance(img_msrcr, s1=0.02, s2=0.02):
    N = img_msrcr.size
    s1 = max(s1, 0.005)
    s2 = max(s2, 0.005)
    Vmin = np.partition(img_msrcr.flatten(), int(N * s1))[int(N * s1)]
    Vmax = np.partition(img_msrcr.flatten(), int(N * (1 - s2)) - 1)[int(N * (1 - s2)) - 1]
    img_msrcr = np.clip(img_msrcr, Vmin, Vmax)
    return (img_msrcr - Vmin) * 255 / (Vmax - Vmin)

def simplest_color_balance_multi_channel(img_msrcr, s1, s2):
    if img_msrcr.ndim != 3:
        raise ValueError("Input image must be a multi-channel image (H×W×C)")
    balanced_img = np.stack([simplest_color_balance(img_msrcr[:, :, c], s1, s2) for c in range(img_msrcr.shape[2])], axis=-1)
    return np.clip(balanced_img, 0, 255).astype(img_msrcr.dtype)

def get_dir(flag=True):
    if flag:
        import inspect
        caller_frame = inspect.stack()[1]
        return os.path.dirname(os.path.realpath(caller_frame.filename))
    else:
        return os.path.dirname(os.path.realpath(__file__))