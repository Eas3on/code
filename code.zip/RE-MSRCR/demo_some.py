import os
import cv2
from code.retinex_red_enhance import retinex_MSRCR


def create_directory(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def process_image(img_path, result_dir):
    img = cv2.imread(img_path)
    processed_img = retinex_MSRCR(img)
    original_name = os.path.basename(img_path)
    save_path = os.path.join(result_dir, original_name)
    cv2.imwrite(save_path, processed_img)


def main():
    base_dir = os.path.dirname(__file__)
    img_dir = os.path.join(base_dir, r'C:...')
    result_dir = os.path.join(base_dir, 'results_val')
    create_directory(result_dir)
    image_files = [f for f in os.listdir(img_dir) if f.endswith(('.jpg', '.png'))]
    for image_file in image_files:
        img_path = os.path.join(img_dir, image_file)
        process_image(img_path, result_dir)


if __name__ == '__main__':
    main()